module Gameplay;

Ability::Ability(char symbol): symbol{symbol}, used{false} {}


module Virus;
import Link;
import Coords;


Virus::Virus(int level, Coords coords, char symbol): Link{level, coords, 'V', symbol} {}

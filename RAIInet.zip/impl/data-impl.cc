module Data;

import Link;
import Coords;

Data::Data(int level, Coords coords, char symbol): Link{level, coords, 'D', symbol} {}

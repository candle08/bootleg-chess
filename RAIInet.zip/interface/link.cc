export module Link;
import Coords;
import <string>;

using namespace std; 
export struct Link {
    int level; // Level on a scale of 1 to 4
    Coords coords;
    char type; // Board::VIRUS or Board::DATA
    bool download_status; // whether or not the link has been downloaded
    char symbol; // its symbol on the board
    bool revealed; // whether or not a link has been revealed
    int linkboost; // whether or not a link has been boosted (0, 1, 2) since linkboost is stackable
    int frozen_on_turn; // number of frozen turns

    Link(int level, Coords coords, char type, char symbol);

    /**
     * Update the coords of the link, but with a Coords parameter
     * @param new_coords The new coords of the link
     */
    void move(const Coords& new_coords);
}; 

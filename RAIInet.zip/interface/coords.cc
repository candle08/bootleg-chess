export module Coords;

export struct Coords {
    int r; // row
    int c; // column
};